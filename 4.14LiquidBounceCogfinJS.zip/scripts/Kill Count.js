//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//单钧魔改抄袭亲妈暴毙(谁都可以随便魔改不要删掉这个本JS是开源的)
//By Minger qq2924270322
var scriptName = "Kill count";
var scriptVersion = 1.0;
var scriptAuthor = "Minger";
script.import('lib/minecraftUtils.js');
script.import('lib/timingFunctions.js');
script.import('lib/glFunctions.js');
script.import('lib/systemFunctions.js');   
var r, g, b, rainbowspeed;
var thicc;
var borderColor;
var borderOpacity;
var borderColorComplete = '0x' + borderOpacity + borderColor;
var rainbowBoolean;
var count = 0
var c;
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat')

function NMSL() {
	var Count = value.createBoolean("Count", true);
	var Speak = value.createBoolean("Speak", true);
	var NameFake = value.createBoolean("NameFake", true);
	var TianKeng = value.createBoolean("TianKeng", true);
    this.getName = function () {
        return "Ka count";
    };

    this.getDescription = function () {
        return "Minger:/";
    };

    this.getCategory = function () {
        return "Fun";
    };
	
    this.onEnable = function () {
		borderOpacity = 'FF';
		borderColor = 'DA70D6';
		c = 0;
		thicc = 2;
		rainbowspeed = 40 / 500;  
    };

	this.onPacket = function(event) {
	var packet = event.getPacket();
	if(packet instanceof S02PacketChat) {	
        if(Count.get() == true) {
       	    if(packet.getChatComponent().getUnformattedText().contains(mc.getSession().getUsername() + "[")) {
			    if(packet.getChatComponent().getUnformattedText().contains("杀死了")) {
				    count = count + 1
					if (Speak.get() == true) {
		                if (count == 10) {
				            mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了十个人了");
			            }
			            if (count == 30) {
				            mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了三十个人了");
			            }
			            if (count == 50) {
				            mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了五十个人了");
			            }
			            if (count == 100) {
			                mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了一百个人了");
							}
			            }
		            if (NameFake.get() == true) {
		                if (count == 10) {
				            commandManager.executeCommand(".Nameprotect fakename &dAquaVit&8[大杀特杀]");
			            }
			            if (count == 30) {
				            commandManager.executeCommand(".Nameprotect fakename &dAquaVit&3[无人能挡]");
			            }
			            if (count == 50) {
				            commandManager.executeCommand(".Nameprotect fakename &dAquaVit&6[接近神了]");
			            }
			            if (count == 100) {
			                commandManager.executeCommand(".Nameprotect fakename &dAquaVit&4[主宰比赛]");
							}
			            } 
					}
				}
			}
        if(TianKeng.get() == true) {
       	    if(packet.getChatComponent().getUnformattedText().contains("击杀!")) {
			    if(packet.getChatComponent().getUnformattedText().contains("你击杀了")) {
				    count = count + 1
					if (Speak.get() == true) {
		                if (count == 10) {
				            mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了十个人了");
			            }
			            if (count == 30) {
				            mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了三十个人了");
			            }
			            if (count == 50) {
				            mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了五十个人了");
			            }
			            if (count == 100) {
			                mc.thePlayer.sendChatMessage("@" + "[" + "LiquidBounceHytUser-" + mc.getSession().getUsername() + "]" + " 我已经使用LiquidBounceForHyt配置杀了一百个人了");
							}
			            }
		            if (NameFake.get() == true) {
		                if (count == 10) {
				            commandManager.executeCommand(".Nameprotect fakename &dAquaVit&8[大杀特杀]");
			            }
			            if (count == 30) {
				            commandManager.executeCommand(".Nameprotect fakename &dAquaVit&3[无人能挡]");
			            }
			            if (count == 50) {
				            commandManager.executeCommand(".Nameprotect fakename &dAquaVit&6[接近神了]");
			            }
			            if (count == 100) {
			                commandManager.executeCommand(".Nameprotect fakename &dAquaVit&4[主宰比赛]");
							}
			            } 
				    } 
                } 
            } 				
        } 						
	}
    
    this.onUpdate = function () {
		if (mc.ingameGUI.getChatGUI().getChatOpen() == false) {
			if (true) {
				if (44 > c) {
					r = parseInt((Math.sin(c + Math.PI) + 1) * 127.5);
					g = parseInt((Math.sin(c + (Math.PI / 2)) + 1) * 127.5);
					b = parseInt(((Math.sin(c) + 1) * 127.5));
					c = c + rainbowspeed;
					borderColor = ('0' + r.toString(16)).slice(-2) + ('0' + g.toString(16)).slice(-2) + ('0' + b.toString(16)).slice(-2)
				} else {
					c = 0;
				}
			}
		}
	}
	this.onRender2D = function() {
		if (mc.ingameGUI.getChatGUI().getChatOpen() == false) {
			var mcHeight = getScaledHeight();
			var mcWidth = getScaledWidth();
			borderColorComplete = '0x' + borderOpacity + borderColor;
			mc.fontRendererObj.drawStringWithShadow("击杀: " + count, mcWidth - mcWidth / 2 + 40, mcHeight - mcHeight / 2 + 15, 0x00d6ff)
		}
	}
	this.addValues = function(values) {
		values.add(Count);
		values.add(Speak);
		values.add(NameFake);
		values.add(TianKeng);
    }
}

var NSML = new NMSL();

var NMML;

function onLoad() {

}

function onEnable() {
    NMML = moduleManager.registerModule(NSML);
}

function onDisable() {
    moduleManager.unregisterModule(NMML);
}